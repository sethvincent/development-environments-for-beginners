# Thanks!

Thank you for buying Development environments for beginners!

Suggest changes/additions and report errors at the book's issues queue: https://github.com/sethvincent/dev-envs-book/issues

And feel free to email me about the book at seth@superbigtree.com.

## Changelog:

### v0.1.1 - August 18, 2013
- added language basics to javascript and ruby chapters
- added a bunch to vagrant chapter
- added to terminal chapter

### v0.1.0 - August 17, 2013
- started all chapters!

Thanks again,
Seth Vincent