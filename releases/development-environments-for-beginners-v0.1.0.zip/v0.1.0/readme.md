# Thanks!

Thank you for buying Development environments for beginners!

Suggest changes/additions and report errors at the book's issues queue: https://github.com/sethvincent/dev-envs-book/issues

And feel free to email me about the book at seth@superbigtree.com.

Thanks again,
Seth Vincent